package inst;

/**
 * Created by burcuozkan on 11/05/16.
 */
public class SkipException extends RuntimeException {

}


/**
 * Before each line, add:
 * SkipException.skipNondet();
 *
 *
 *
 *
 * In the outmost block of an event handler and other async methods add:
 *
 * public void onClick() {
 *     try {
 *
 *         // stmts
 *         //SkipException.skipNondet(); stmt1; ...
 *
 *     } catch(SkipException e) {
 *
 *     }
 * }
 *
 */
