package inst;

import gov.nasa.jpf.vm.Verify;

import java.util.Random;

public class ViolationChecker {

    /**
     * inASYNC is true:
     *  - During an asynchronous procedure that runs in a background thread
     *    Its execution can be skipped at any time in the procedure.
     *  - Just before the execution of an asynchronous procedure that runs in the main thread
     *    Its execution can be skipped just before the procedure.
     *    (No more events can be dispatched and the execution gets blocked if a procedure skips
     *    in the UI thread.)
     */
    private static boolean inASYNC = false;

    private static FieldAccess delayingAccess;
    private static FieldAccess cycleAccess;

    private static FieldAccess exitAccess = null;
    private static FieldAccess tmpExitAccess = null;

    // booleans for [stmt]_shared
    private static boolean firstSet = false;
    private static boolean delayerSet = false;

    // booleans for [stmt]_event
    // whether the current event guessed its exit
    private static boolean exitSetInEvent = false;
    // whether the current event is validated to be in the conflict graph
    private static boolean entrySetInEvent = false;

    // to prevent dependency inside the same event
    private static int curEventID = 0;
    private static int exitAccessIn = 0;
    private static int tmpExitAccessIn = 0;

    // to print dependency info:
    // the last event which guesses "exitAccess" to conflict with "delayingAccess"
    // is dependent to the previous event by exitFrom and entryTo accesses
    private static FieldAccess exitFrom = null;
    private static FieldAccess entryTo = null;
    private static int firstEventID = 0; // just to print info

    private static boolean error = false;

    // bound the search with a limited number of skipping statements
    private static int MAX_SKIP_COUNT = 3;
    private static int skipCount = 0;

    // if a statement delays in the main thread
    // no events/tasks posted to the main thread are allowed to run
    private static boolean inUiThread = true;
    private static boolean skippedInUiThread = false;

    private static Runnable delayingR = null;

    public static void initEvent() {
        // reset the booleans - the previous event might have skipped in a background thread
        inUiThread = true;
        inASYNC = false;

        // block if the previous event is skipped in the UI thread
        //if(skippedInUiThread)
        //    System.out.println("--------------------- IGNORE ----------------- ");
        Verify.ignoreIf(skippedInUiThread);

        curEventID ++;

        // reset event local booleans for [stmt]_event
        entrySetInEvent = false;
        exitSetInEvent = false;

        if (!firstSet) {  // if the first event is not set yet
            boolean first = Verify.getBoolean();
            if (first) {
                // To get annotation from the user
                //Verify.ignoreIf(curEventID != 3);  //Hook to check whether it works in shorter time !

                firstSet = true;
                firstEventID = curEventID;
                // the first event is in the conflict graph
                entrySetInEvent = true;
            }
        }
    }

    public static void endEvent() {

        // assume (entrySetInEvent == exitSetInEvent)
        Verify.ignoreIf(entrySetInEvent != exitSetInEvent);

        // the error is set to true inside the event
        if(error) { // additional guard?
            System.out.println("----------- Violation detected: -----------");
            System.out.println("Access:   " + cycleAccess.toString());
            System.out.println("Cycler:   " + delayingAccess.toString());
            System.out.println("Exit  :   " + exitAccess.toString());
            System.out.println("Dependent by Entry  :   " + entryTo.toString());
            System.out.println("Dependent by Exit  :   " + exitFrom.toString());
            System.out.println("First  :   " + firstEventID);

            assert(false);
        }
    }

    public static void skipNondetJPF(String accessType, String objId, String objName, String fieldName, String methodName) {

        /*if(objName.equals("inst.ViolationChecker")) {
            System.out.println("Skipped violation checker -----------------------");
            return;
        }*/
        FieldAccess currentAccess = new FieldAccess(accessType, objId, objName, fieldName, methodName);

        // a stmt can be skipped or can be guessed as a cycler
        // only if the executing method is asynchronously invoked
        if(inASYNC && skipCount < MAX_SKIP_COUNT /*&& currentAccess.getFieldName().equals("mText")*/) {

            boolean skip = Verify.getBoolean(); // /*(skipCount < maxSkipCount) &&*/ getBoolean();  // skip?

            if(skip) {
                skipCount++;

                if (inUiThread) {
                    skippedInUiThread = true;
                    //System.out.println("Skipped in UI thread: \t" + currentAccess.toString());
                    Verify.ignoreIf(skippedInUiThread);
                }

                boolean isDelaying = Verify.getBoolean();

                // just skip the stmt
                if (!isDelaying) {
                    // System.out.println("Skipped: \t" + currentAccess.toString());

                    throw new SkipException();

                    // delay the stmt - this access will form a cycle in the conflict graph
                } else {
                    delayingAccess = currentAccess;
                    delayerSet = true;

                    //System.out.println("Delayer: ----------------- " + delayingAccess.toString());

                    throw new SkipException();
                }
            }

        } else {

            // nondet guess this access as the exit access (executed once in an event)
            if(firstSet && !exitSetInEvent) {
                boolean exit = Verify.getBoolean();
                if(exit) {
                    if(entrySetInEvent) {
                        exitAccess = tmpExitAccess = currentAccess;
                        exitAccessIn = curEventID;
                    } else {
                        tmpExitAccess = currentAccess;
                        tmpExitAccessIn = curEventID;
                    }
                    exitSetInEvent = true;
                }
            }

            // if the current exitAccess is set by a prev event, nondet guess the entry access
            if (exitAccessIn != curEventID && exitAccess != null && !entrySetInEvent) {
                boolean entry = Verify.getBoolean();
                if(entry) {
                    if(checkConflict(currentAccess, exitAccess)) {
                        // kept just to print info:
                        entryTo = currentAccess;
                        exitFrom = exitAccess;

                        // the current event is validated to be in the cycle
                        exitAccess = tmpExitAccess;
                        exitAccessIn = tmpExitAccessIn;
                        tmpExitAccess = null;
                        entrySetInEvent = true;
                    }
                }
            }

            // if the delayer and the exit accesses are set, nondet go to the delayer stmt
            if(delayerSet && exitAccess != null) {
                boolean gotoDelayed = Verify.getBoolean();
                if(gotoDelayed) {
                    if (checkConflict(exitAccess, delayingAccess)) {
                        error = true;
                        cycleAccess = exitAccess;
                    }
                }
            }
        }
    }

    public static boolean checkConflict(FieldAccess access1, FieldAccess access2) {
        if(access1.getObjId().equals(access2.getObjId()) && access1.getFieldName().equals(access2.getFieldName())) {
            if(access1.getAccessType().equals("PUT") || access2.getAccessType().equals("PUT")) {
                return true;

            }
        }
        return false;
    }

    public static void setDelayingRunnable(Runnable r) {
        delayingR = r;
    }
    private static boolean getRandomBoolean() {
        Random r = new Random();
        return r.nextBoolean();
    }

    public static void setAsync(boolean b) {
        inASYNC = b;
    }

    public static void logRW(String accessType, String objId, String className, String fieldName, String methodName) {
        System.out.println(accessType + "\t" + objId + "\t" + className + "\t" + fieldName + "\t" + methodName);
    }

    public static void setInUiThread(boolean b) {
        inUiThread = b;
    }
}

/**
 * Insert the instrumentation statements before each read/write stmt of an event
 *
 * public void onClick() {
 *    ViolationChecker.skipNondetJPF();
 *    stmt1;
 *
 *    ViolationChecker.skipNondetJPF();
 *    stmt2;
 *
 *    ...
 *
 * }
 *
 *  Invoke an event handler inside try/catch blocks
 *  public void test() {
 *     try {
 *
 *         ViolationChecker.initEvent();
 *         onClick();
 *         ViolationChecker.endEvent();
 *
 *     } catch(SkipException e) {
 *
 *     }
 * }
*/

