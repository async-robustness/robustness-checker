package inst;

/**
 * Created by burcuozkan on 13/05/16.
 */
public class FieldAccess {
    private String objId;
    private String objName;
    private String fieldName;
    private String accessType; // GET or PUT
    private String inMethod;

    public FieldAccess(String accessType, String objId, String objName, String fieldName, String inMethod) {
        this.objId = objId;
        this.objName = objName;
        this.fieldName = fieldName;
        this.accessType = accessType;
        this.inMethod = inMethod;
    }

    public String getObjId() {
        return objId;
    }

    public String getFieldName() {
        return fieldName;
    }

    public String getAccessType() {
        return accessType;
    }

    public String toString() {
        return accessType + "\t" + objId + "\t" + objName + "\t" + fieldName + "\t" + "In: " + inMethod + "\n";
    }
}
