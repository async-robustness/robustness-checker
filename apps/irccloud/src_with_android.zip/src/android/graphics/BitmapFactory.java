package android.graphics;

import java.io.InputStream;

public class BitmapFactory {
  public static BitmapFactory TOP = new BitmapFactory();


  public BitmapFactory(){
    // no must se;
    // no may se;
  }

  public static Bitmap decodeResource(android.content.res.Resources param0, int param1){
    // begin must se;
    // end must se;
    // no may se;
    return Bitmap.TOP;
  }

  public static Bitmap decodeStream(InputStream is) {
    return Bitmap.TOP;
  }

  ///**(B) Modification to JPA's models (B)**//

  public static Bitmap decodeResource(android.content.res.Resources res, int id, Options opts) {
    return Bitmap.TOP;
  }

  public static Bitmap decodeFile(String pathName, Options opts) {
    return Bitmap.TOP;
  }

  public static Bitmap decodeStream(InputStream is, Object outPadding, Options opts) {
    return Bitmap.TOP;
  }

  public static class Options {

    public Options() {
      inDither = false;
      inScaled = true;
      inPremultiplied = true;
    }

    public Bitmap inBitmap;

    public boolean inJustDecodeBounds;

    public Bitmap.Config inPreferredConfig = Bitmap.Config.ARGB_8888;

    public boolean inPremultiplied;

    public boolean inDither;

    public int inDensity;

    public int inTargetDensity;

    public int inScreenDensity;

    public boolean inScaled;

    public boolean inPurgeable;

    public boolean inInputShareable;

    public boolean inPreferQualityOverSpeed;

    public int outWidth;

    public int outHeight;

    public String outMimeType;

    public byte[] inTempStorage;

    private native void requestCancel();

    public boolean mCancel;

    public void requestCancelDecode() {
      mCancel = true;
      requestCancel();
    }
  }

  ///**(B) Modification to JPA's models (B)**//
}