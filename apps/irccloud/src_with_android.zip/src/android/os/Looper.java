/*
 * Copyright (C) 2006 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.os;

/**
 * I kept Looper since it is used in the references etc in the Android apps
 * However, the mechanism is made synchronous
 * All messages are already handled synchronously, without going into the looper
 */

public final class Looper {

    public static Looper LOOPER_TOP = new Looper();

    public Looper() {

    }

    public static void prepare() {
    }

    public static Looper getMainLooper() {
        return LOOPER_TOP;
    }


    public static void loop() {

    }

    /**
     * Return the Looper object associated with the current thread.  Returns
     * null if the calling thread is not associated with a Looper.
     */
    public static Looper myLooper() {
        return LOOPER_TOP;
    }


    public void quit() {

    }

    public void quitSafely() {

    }

}
