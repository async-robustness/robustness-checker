package android.os;

/**
 * Created by burcuozkan on 11/06/16.
 */
public class Build {

    public static final String MODEL = "model";


    public static class VERSION {

        public static final String INCREMENTAL = "incremental";

        public static final String RELEASE = "release";

        public static final String SDK = "sdk";

        public static final int SDK_INT = 19;

        public static final String CODENAME = "codename";

    }
}
