package android.os;

/**
 * Created by burcuozkan on 05/05/16.
 */
public interface Parcelable {
}
