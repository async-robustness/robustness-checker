package android.os;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class SystemClock {

    public static void sleep(int duration) {

    }
}
