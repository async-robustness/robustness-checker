package android.net;

import android.os.Parcelable;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class Uri implements Parcelable {

    public static Uri parse(String uriString) {
        return new Uri();
    }

    public String getScheme() {
        return "";
    }

    public String getHost() {
        return "";
    }

    public String getPath() {
        return "";
    }

    public int getPort() {
        return 0;
    }
}
