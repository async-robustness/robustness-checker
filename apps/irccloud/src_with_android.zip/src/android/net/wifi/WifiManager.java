package android.net.wifi;

/**
 * Created by burcuozkan on 12/06/16.
 */
public class WifiManager {

    public class WifiLock {
        public void acquire() {

        }

        public void release() {

        }

        public boolean isHeld() {
            return false;
        }

    }

    public WifiLock createWifiLock(int lockType, String tag) {
        return new WifiLock();
    }

    public WifiLock createWifiLock(String tag) {
        return new WifiLock();
    }



}


