package android.net;

import android.content.Context;

/**
 * Created by burcuozkan on 11/06/16.
 */
public class Proxy {
    public static final String getHost(Context ctx) {
        return "";
    }

    public static final int getPort(Context ctx) {
        return -1;
    }
}
