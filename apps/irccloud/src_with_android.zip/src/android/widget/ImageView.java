package android.widget;

import android.content.Context;
import android.view.View;
//import android.graphics.drawable.Drawable;

public class ImageView extends View {

  public static ImageView TOP;
  public int imageResource;

  public ImageView() {
    if (TOP == null) {
      TOP = this;
    }
  }

  public ImageView(int resId) {
    if (TOP == null) {
      TOP = this;
    }
  }

  public ImageView(Context c) {
    if (TOP == null) {
      TOP = this;
    }
  }

  public void setImageBitmap(android.graphics.Bitmap param0) {
  }

  public void setImageResource(int resId) {
    imageResource = resId;
  }

  /*public Drawable getDrawable() {
    return new Drawable();
  }

  public void setImageDrawable(Drawable param0) {
  }*/

}