package android.widget;

import android.content.Context;

public class Spinner extends AbsSpinner {
    public Spinner(Context context) {
    }

    public Spinner(Context context, int mode) {
    }

    public void setSelection(int position) {
    }
}
