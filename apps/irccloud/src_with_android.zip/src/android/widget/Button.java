package android.widget;

import android.view.View;

/**
 * Created by burcuozkan on 02/06/16.
 */
public class Button extends TextView {

    public Button() {
    }

    public Button(int resId) {
    }
}
