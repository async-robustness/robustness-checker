package android.widget;

import android.content.Context;
import android.text.Editable;
import android.text.Spanned;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;

import java.util.ArrayList;

/**
 * Created by burcuozkan on 02/06/16.
 * Kept setText method calls to track the object fields
 * which are read and used as a method parameter inside the app
 */
public class TextView extends View {

    private boolean mEnabled;
    private CharSequence mText = "";

    // the String text is kept only for display purposes
    public enum BufferType {
        NORMAL, SPANNABLE, EDITABLE,
    }

    public TextView() {
    }

    public TextView(Context c) {
    }

    public TextView(int textId) {
    }

    public TextView(String text) {
        mText = text;
    }

    public CharSequence getText() {
        return mText;
    }

    public final void setText(CharSequence text) {
        mText = text;
    }

    public final void setTextKeepState(CharSequence text) {
        mText = text;
    }

    public void setText(CharSequence text, BufferType type) {
        mText = text;
    }

    private void setText(CharSequence text, BufferType type,
                         boolean notifyBefore, int oldlen) {
        mText = text;
    }

    public final void setText(char[] text, int start, int len) {
        mText = new String(text);
    }

    public final void setText(int resid) {
        mText = Integer.toString(resid);
    }

    public final void setText(Spanned s) {
        mText = s.toString();
    }

    public final void setText(int resid, BufferType type) {
        mText = Integer.toString(resid);
    }

    public void setTypeface(Object tf) {

    }

    public void setTextColor(int color) {

    }

    public void setSelection(int i) {

    }

    public void setSelected(boolean b) {

    }

    public int getSelectionStart() {
        return 0;
    }

    public final void append(CharSequence text) {
        System.out.println("oooy oy 1");
        setText("appended");
        //append(text, 0, text.length());
    }

   /* public void append(CharSequence text, int start, int end) {
        System.out.println("oooy oy 2");

        if (!(mText instanceof Editable)) {
            System.out.println("oooy oy");
            //setText(mText, BufferType.EDITABLE);
        }

        // just writes to Editable mtext
        //setText("appended");
    }*/

    public void setEnabled(boolean enabled) {
        mEnabled = enabled;
    }

    private ArrayList<TextWatcher> mListeners;

    public void addTextChangedListener(TextWatcher watcher) {
        if (mListeners == null) {
            mListeners = new ArrayList<TextWatcher>();
        }

        mListeners.add(watcher);
    }

    public void removeTextChangedListener(TextWatcher watcher) {
        if (mListeners != null) {
            int i = mListeners.indexOf(watcher);

            if (i >= 0) {
                mListeners.remove(i);
            }
        }
    }

    public void callOnTextChangedListener(int listenerIndex, CharSequence s, int start, int before, int count) {
        if(mListeners.get(listenerIndex) == null)
            return;

        mListeners.get(listenerIndex).onTextChanged(s, start, before, count);
    }

    OnEditorActionListener onEditorActionListener;

    public void setOnEditorActionListener(OnEditorActionListener l) {
        onEditorActionListener = l;
    }

    public interface OnEditorActionListener {
        boolean onEditorAction(TextView v, int actionId, KeyEvent event);
    }

    public void callOnEditorActionListener(TextView v, int actionId, KeyEvent event) {
        if(onEditorActionListener == null)
            return;

        onEditorActionListener.onEditorAction(v, actionId, event);
    }
}

