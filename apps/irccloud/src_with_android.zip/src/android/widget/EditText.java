package android.widget;

import android.content.Context;
import android.view.View;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class EditText extends TextView {
    private boolean isEnabled = false;

    public EditText() {
    }

    public EditText(Context c) {
    }

    public EditText(int resId) {
    }

    public String getText() {
        return super.getText().toString();
    }

    public void setText(String input) {
        super.setText(input);
    }

    public boolean isEnabled() {
        return isEnabled;
    }

    public void setEnabled(boolean b) {
        isEnabled = b;
    }

}
