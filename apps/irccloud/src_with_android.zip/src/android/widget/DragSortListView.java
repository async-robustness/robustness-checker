package android.widget;

/**
 * Created by burcuozkan on 10/06/16.
 */
public class DragSortListView extends ListView {

    private DropListener mListener;

    public void setDropListener(DropListener l) {
        mListener = l;
    }

    public interface DropListener {
         void drop(int from, int to);
    }


}
