package android.widget;

import android.view.View;

public class ProgressBar extends View {
    public ProgressBar() {

    }

    public ProgressBar(int resId) {

    }

    public void setProgress(int value) {

    }

    public int getProgress() {
        return 0;
    }
}
