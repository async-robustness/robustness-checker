package android.widget;


/**
 * Created by burcuozkan on 10/06/16.
 */
public class AutoCompleteTextView extends TextView {
    private ListAdapter mAdapter;

    public void setAdapter(ListAdapter a) {
        mAdapter = a;
    }
}
