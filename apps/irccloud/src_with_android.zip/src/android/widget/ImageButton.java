package android.widget;

/**
 * Created by burcuozkan on 07/06/16.
 */
public class ImageButton extends ImageView {

    public ImageButton(int resId) {

    }
}
