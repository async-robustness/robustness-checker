package android.widget;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class CheckBox extends CompoundButton {

    private boolean checked = false;

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public CheckBox() {
    }

    public CheckBox(int resId) {
    }

}
