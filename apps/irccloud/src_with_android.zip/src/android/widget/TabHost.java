package android.widget;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class TabHost {

    private int currentTab = 0;
    private OnTabChangeListener mOnTabChangeListener;

    public int getCurrentTab() {
        return currentTab;
    }

    public void setCurrentTab(int tab) {
        currentTab = tab;
    }

    public void setOnTabChangedListener(OnTabChangeListener l) {
        mOnTabChangeListener = l;
    }

    public interface OnTabChangeListener {
        void onTabChanged(String tabId);
    }
}
