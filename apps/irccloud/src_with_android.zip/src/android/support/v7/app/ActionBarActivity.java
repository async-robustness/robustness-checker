package android.support.v7.app;

import android.app.Activity;
import android.support.v4.app.FragmentActivity;

/**
 * Created by burcuozkan on 07/06/16.
 */
public class ActionBarActivity extends FragmentActivity {

    private ActionBar mActionBar = new ActionBar();

    public ActionBar getSupportActionBar() {
        return mActionBar;
    }
}
