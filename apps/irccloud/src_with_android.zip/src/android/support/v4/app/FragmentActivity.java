package android.support.v4.app;

import android.app.Activity;

/**
 * Created by burcuozkan on 07/06/16.
 */
public class FragmentActivity extends Activity {

    private FragmentManager mFragmentManager = new FragmentManager();

    public FragmentManager getSupportFragmentManager() {
        return mFragmentManager;
    }

}
