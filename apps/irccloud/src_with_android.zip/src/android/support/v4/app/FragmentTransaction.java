package android.support.v4.app;

/**
 * Created by burcuozkan on 07/06/16.
 */
public class FragmentTransaction {

    public FragmentTransaction replace(int containerViewId, Fragment fragment) {
        return new FragmentTransaction();
    }

    public FragmentTransaction attach(Fragment f) {
        return new FragmentTransaction();
    }

    public FragmentTransaction detach(Fragment f) {
        return new FragmentTransaction();
    }

    public int commit() {
        return 0;
    }
}
