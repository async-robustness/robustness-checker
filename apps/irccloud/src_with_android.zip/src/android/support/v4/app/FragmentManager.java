package android.support.v4.app;

/**
 * Created by burcuozkan on 07/06/16.
 */
public class FragmentManager {

    //TODO
    public Fragment findFragmentById(int resId) {
        return new Fragment();
    }

    public FragmentTransaction beginTransaction() {
        return new FragmentTransaction();
    }

    public Fragment findFragmentByTag(String tag) {
        return null;
    }
}
