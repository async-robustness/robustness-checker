package android.database.sqlite;

import android.database.SQLException;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class SQLiteStatement {


    public void clearBindings() {

    }

    public void bindString(int i, String s) {

    }

    public void bindLong(int i, long s) {

    }

    public long executeInsert() {
        return 0;
    }
}
