/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.database.sqlite;

import android.content.Context;

public abstract class SQLiteOpenHelper {

    public SQLiteOpenHelper(Context context, String name, Object factory, int version) {
        this(context, name, factory, version, null);
    }

    public SQLiteOpenHelper(Context context, String name, Object factory, int version,
            Object errorHandler) {

    }

    public SQLiteDatabase getWritableDatabase() {
        return new SQLiteDatabase();
    }

    public SQLiteDatabase getReadableDatabase() {
        return new SQLiteDatabase();
    }

    private SQLiteDatabase getDatabaseLocked(boolean writable) {
        return new SQLiteDatabase();
    }

    public void close() {
    }

    public void onConfigure(SQLiteDatabase db) {}

    public abstract void onCreate(SQLiteDatabase db);

    public abstract void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion);

    /*public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        throw new SQLiteException("Can't downgrade database from version " +
                oldVersion + " to " + newVersion);
    }*/
    public void onOpen(SQLiteDatabase db) {}
}
