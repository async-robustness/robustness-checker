package android.content.pm;

import android.content.Intent;

import java.util.ArrayList;
import java.util.List;

public class PackageManager {


  public static class NameNotFoundException extends Exception {
    public NameNotFoundException() {
    }

    public NameNotFoundException(String name) {
      super(name);
    }
  }

  public PackageInfo packageInfo = new PackageInfo();

  public PackageManager() {

  }


  public PackageInfo getPackageInfo() {
    return packageInfo;
  }

  public PackageInfo getPackageInfo(String packageName, int flags) throws NameNotFoundException {
    return packageInfo;
  }

  public List queryIntentActivities(Intent intent, int flags) {
    return new ArrayList();
  }

}
