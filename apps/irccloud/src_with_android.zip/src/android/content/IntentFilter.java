package android.content;

import java.util.ArrayList;

/**
 * Created by burcuozkan on 10/06/16.
 */
public class IntentFilter {

    private final ArrayList<String> mActions = new ArrayList<String>();

    public final void addAction(String action) {
        if (!mActions.contains(action)) {
            mActions.add(action.intern());
        }
    }
}
