package android.content.res;

/**
 * Created by burcuozkan on 07/06/16.
 */
public class Configuration {
}
