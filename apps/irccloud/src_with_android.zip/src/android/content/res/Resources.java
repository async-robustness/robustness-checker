package android.content.res;

import java.io.IOException;
import java.io.InputStream;

/**
 * Stubs for resources
 */
public class Resources {

    public String getString(int id) throws NotFoundException {
        CharSequence res = getText(id);
        if (res != null) {
            return res.toString();
        }
        throw new NotFoundException("String resource ID #0x"
                + Integer.toHexString(id));
    }

    public String getString(int id, Object... formatArgs) throws NotFoundException {
        return "";
    }

    public String[] getStringArray(int id) throws NotFoundException {
        String[] s = {""};
        return s;
    }

    public int[] getIntArray(int id) throws NotFoundException {
        int[] i = {0};
        return i;
    }


    public CharSequence getText(int id) throws NotFoundException {
        return "";
    }

    public Object getDrawable(int resId) {
        return new Object();
    }

    public int getColorStateList(int id) {
        return id;
    }

    public int getColor() {
        return 0;
    }

    public int getColor(int resId) {
        return 0;
    }

    public InputStream openRawResource(int resId) {
        return new InputStream() {
            @Override
            public int read() throws IOException {
                return 0;
            }
        };
    }

    public static class NotFoundException extends RuntimeException {
        public NotFoundException() {
        }

        public NotFoundException(String name) {
            super(name);
        }
    }
}
