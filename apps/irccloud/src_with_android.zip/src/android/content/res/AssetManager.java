package android.content.res;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by burcuozkan on 07/06/16.
 */
public class AssetManager {
    public final InputStream open(String fileName) throws IOException {
        return null;
    }
}
