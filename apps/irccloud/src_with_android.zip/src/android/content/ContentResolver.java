package android.content;

import android.net.Uri;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class ContentResolver {

    public String getType(Uri type) {
        return "";
    }

    public final InputStream openInputStream(Object uri) throws FileNotFoundException {
        return new InputStream() {
            @Override
            public int read() throws IOException {
                return 0;
            }
        };
    }
}
