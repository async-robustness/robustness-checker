package android.content;

import android.app.NotificationManager;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.app.Application;
import android.net.wifi.WifiManager;
import android.view.LayoutInflater;
import inst.SkipException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class Context {
    public static final int MODE_PRIVATE = 0x0000;

    public static final String CONNECTIVITY_SERVICE = "connectivity";
    public static final String LAYOUT_INFLATER_SERVICE = "layout_inflater";
    public static final String NOTIFICATION_SERVICE = "notification";
    public static final String LOCATION_SERVICE = "location";
    public static final String WIFI_SERVICE = "wifi";


    private String packageName;
    private PackageManager mPackageManager = new PackageManager();
    private AssetManager mAssetManager = new AssetManager();
    private ApplicationInfo mApplicationInfo = new ApplicationInfo();
    private SharedPreferences mSharedPreferences = new SharedPreferences();
    private Resources mResources = new Resources();

    private List<BroadcastReceiver> mBroadcastReceivers = new ArrayList<BroadcastReceiver>();

    public static Application app;

    public void initApplication(Class<? extends Application> clazz) {
        if(app == null) {
            try{
                app = (Application) clazz.newInstance();
                app.onCreate();
            } catch (SkipException e) {
                throw e;
            } catch (Exception e) {
                System.out.println("The application cannot be created: " + clazz.toString());
            }
        }
    }

    public Application getApplication() {
        return app;
    }

    public Context getApplicationContext() {
        return this;
    }

    public ApplicationInfo getApplicationInfo() {return mApplicationInfo; }

    public SharedPreferences getSharedPreferences(String name, int mode) {
        return mSharedPreferences;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String name) {
        packageName = name;
    }

    public PackageManager getPackageManager() {
        return mPackageManager;
    }

    public ContentResolver contentResolver = new ContentResolver();

    public Resources getResources() {
        return mResources;
    }

    public AssetManager getAssets() { return mAssetManager; }

    public  ContentResolver getContentResolver() {
        return contentResolver;
    }

    public String getString(int id) {
        return "";
    }

    public String getString(int id, String s) {
        return "";
    }

    public String getString(int id, float size) {
        return "";
    }

    public File getFilesDir() {
        return new File("");
    }

    public File getExternalFilesDir(String type) {
        return null;
    }

    public Object getSystemService(String name){
        if(name.equalsIgnoreCase(Context.CONNECTIVITY_SERVICE)) {
            return new ConnectivityManager();
        }
        if(name.equalsIgnoreCase(Context.NOTIFICATION_SERVICE)) {
            return new NotificationManager();
        }
        if(name.equalsIgnoreCase(Context.WIFI_SERVICE)) {
            return new WifiManager();
        }
        return new Object();
    }

    public void startActivity(Intent intent) {
        /*
        onPause();
        onStop();
        Activity act = intent.getNewActivity();
        act.onCreate();
        act.onStart();
        act.onResume();*/

        //TODO - now compiles but does not start a new activity
        /*final Intent routeselect = new Intent(mContext, RouteselectActivity.class);
        final String pkgstr = mContext.getApplicationContext().getPackageName();
        routeselect.putExtra(pkgstr + ".stop_id", mStopid);
        routeselect.putExtra(pkgstr + ".stop_name", stopname);
        mContext.startActivity(routeselect);*/
    }

    public void startService(Intent intent) {
        //TODO
    }


    public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter) {
        mBroadcastReceivers.add(receiver);
        return new Intent();
    }

    public void unregisterReceiver(BroadcastReceiver receiver) {
        mBroadcastReceivers.remove(receiver);
    }

    //public Intent registerReceiver(BroadcastReceiver receiver, IntentFilter filter, String broadcastPermission, Handler scheduler);


    public void sendBroadcast(Intent intent) {
        // resolve synchronously
        for(BroadcastReceiver br: mBroadcastReceivers) {
            br.onReceive(this, intent);
        }
    }
}
