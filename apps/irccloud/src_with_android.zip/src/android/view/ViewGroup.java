package android.view;

import android.content.Context;

/**
 * This class is only used as a parameter type for some overriden methods
 */
public class ViewGroup extends View {

    public ViewGroup() {

    }

    public ViewGroup(Context context) {
    }


}
