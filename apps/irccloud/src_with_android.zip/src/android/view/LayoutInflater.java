package android.view;

import android.content.Context;

/**
 * Created by burcuozkan on 10/06/16.
 */
public class LayoutInflater {

    private Context mContext;

    public Context getContext() {
        return mContext;
    }

    public View inflate(int resource, ViewGroup root) {
        return inflate(resource, root, root != null);
    }


    public View inflate(int resource, ViewGroup root, boolean attachToRoot) {
        return new View(resource);
    }
}
