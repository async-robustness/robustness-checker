package android.view;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class MenuItem {

    private int itemId;
    private AdapterContextMenuInfo info;

    public MenuItem() {
        itemId = -1;
    }

    public MenuItem(int id) {
        itemId = id;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int id) {
        itemId = id;
    }

    public void setTitle(int resId) {
    }

    public void setVisible(boolean b) {
    }

    public void setEnabled(boolean b) {
    }


    public AdapterContextMenuInfo getMenuInfo() {
        return info;
    }

    public interface AdapterContextMenuInfo {

    }
}
