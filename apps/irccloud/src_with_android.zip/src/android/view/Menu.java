package android.view;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class Menu {

    public MenuItem findItem(int resId) {
        return new MenuItem();
    }
}
