package android.view;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class ContextMenu {

    public class ContextMenuInfo {

    }
}
