package android.view;

import android.content.Context;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import java.util.HashMap;
import java.util.Map;

public class View {

  private int mID;
  private Object mTag;
  private OnClickListener mOnClickListener = null;
  private OnKeyListener mOnKeyListener = null;
  private OnTouchListener mOnTouchListener = null;
  protected OnFocusChangeListener mOnFocusChangeListener;
  protected OnLongClickListener mOnLongClickListener;

  private Context context;

  public View() {
    context = new Context();
  }

  public View(int resId) {
    context = new Context();
  }

  public View(Context context) {
    this.context = context;
  }

  public int getTop() {
    return 0;
  }

  public int getId() {
    return mID;
  }

  public void setId(int mID) {
    this.mID = mID;
  }

  public void setTag(final Object tag) {
    mTag = tag;
  }

  public Object getTag() {
    return mTag;
  }

  public void setOnClickListener (OnClickListener listener){
    mOnClickListener = listener;
  }

  public boolean callOnClick() {
    if(mOnClickListener == null) {
      return false;
    }

    mOnClickListener.onClick(new View());
    return true;
  }

  public interface OnClickListener {
    void onClick(View v);
  }

  public boolean callOnKey(int keyCode, KeyEvent event) {
    if(mOnKeyListener == null) {
      return false;
    }

    mOnKeyListener.onKey(new View(), keyCode, event);
    return true;
  }

  public void setOnKeyListener(OnKeyListener l) {
    mOnKeyListener = l;
  }

  public interface OnKeyListener {
    boolean onKey(View v, int keyCode, KeyEvent event);
  }

  public boolean callOnTouch(MotionEvent event) {
    if(mOnTouchListener == null) {
      return false;
    }

    mOnTouchListener.onTouch(new View(), event);
    return true;
  }

  public void setOnTouchListener(OnTouchListener l) {
    mOnTouchListener = l;
  }

  public interface OnTouchListener {
    boolean onTouch(View v, MotionEvent event);
  }

  public boolean callOnLongClick() {
    if(mOnLongClickListener == null) {
      return false;
    }

    mOnLongClickListener.onLongClick(new View());
    return true;
  }

  public interface OnLongClickListener {
    boolean onLongClick(View v);
  }

  public void setOnLongClickListener(OnLongClickListener l) {
    mOnLongClickListener = l;
  }

  public void setOnFocusChangeListener(OnFocusChangeListener l) {
    mOnFocusChangeListener = l;
  }

  public interface OnFocusChangeListener {
    void onFocusChange(View v, boolean hasFocus);
  }

  public void invalidate() {

  }

  public CharSequence getContentDescription() {
    return "";
  }

  public int getHeight() {
    return 0;
  }

  public void setBackgroundResource(int resid) {

  }

  public View getChildAt(int i) {
    return new View(); //cast?
  }

  public boolean isEnabled() {
    return true;
  }

  public void setEnabled(boolean b) {

  }

  public static final int VISIBLE = 0x00000000;

  public static final int INVISIBLE = 0x00000004;

  public static final int GONE = 0x00000008;

  private int visibility;

  public int getVisibility() {
    return visibility;
  }

  public void setVisibility(int visibility) {
    this.visibility = visibility;
  }


  public void setContentDescription(CharSequence contentDescription) {

  }

  public InputConnection onCreateInputConnection(EditorInfo outAttrs) {
    return null;
  }
  public boolean onKeyPreIme(int keyCode, KeyEvent event) {
    return false;
  }

  public void post(Runnable r) {
    // synchronously run!
    r.run();
  }

  public Map viewsById = new HashMap<Integer, View>();

  public View findViewById(int resId, Class viewClass) {
    View v = (View) viewsById.get(resId);
    if(v == null) {
      try {
        v = (View) viewClass.newInstance();
        viewsById.put(resId, v);
      } catch (InstantiationException e) {
        e.printStackTrace();
      } catch (IllegalAccessException e) {
        e.printStackTrace();
      }
    }

    return v;
  }

  public View findViewById(int resId) {
    View v = (View) viewsById.get(resId);
    if(v == null) {
      v = new View();
    }
    return v;
  }

}