/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package android.app;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.text.Spanned;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;

public class AlertDialog extends Dialog implements DialogInterface {

    public static final int THEME_TRADITIONAL = 1;
    public static final int THEME_HOLO_DARK = 2;
    public static final int THEME_HOLO_LIGHT = 3;
    public static final int THEME_DEVICE_DEFAULT_DARK = 4;
    public static final int THEME_DEVICE_DEFAULT_LIGHT = 5;

    private static OnClickListener mPositiveButtonListener;
    private static OnClickListener mNegativeButtonListener;
    private static OnClickListener mNeutralButtonListener;
    private static OnMultiChoiceClickListener mOnCheckboxClickListener;
    private static AdapterView.OnItemSelectedListener mOnItemSelectedListener;
    private static OnClickListener mOnClickListener;
    private static OnKeyListener mOnKeyListener;
    private static OnCancelListener mOnCancelListener;
    private static OnDismissListener mOnDismissListener;

    public AlertDialog() {

    }

    public void setTitle(CharSequence title) {
    }


    public void setCustomTitle(View customTitleView) {

    }
    
    public void setMessage(CharSequence message) {

    }

    public void setView(View view) {

    }

    public void setView(View view, int viewSpacingLeft, int viewSpacingTop, int viewSpacingRight,
            int viewSpacingBottom) {

    }

    public static class Builder {

        public Builder(Context context) {
        }

        public Builder(Context context, int theme) {
        }

        /*public Context getContext() {
            return new Context();
        }*/

        public Builder setTitle(int titleId) {
            return this;
        }

        public Builder setTitle(CharSequence title) {
            return this;
        }

        public Builder setCustomTitle(View customTitleView) {
            return this;
        }

        public Builder setMessage(int messageId) {
            return this;
        }

        public Builder setMessage(Spanned s) {
            return this;
        }

        public Builder setMessage(CharSequence message) {
            return this;
        }

        public Builder setIcon(int iconId) {
            return this;
        }

        public Builder setPositiveButton(int textId, final OnClickListener listener) {
            mPositiveButtonListener = listener;
            return this;
        }

        public Builder setPositiveButton(CharSequence text, final OnClickListener listener) {
            mPositiveButtonListener = listener;
            return this;
        }

        public Builder setNegativeButton(int textId, final OnClickListener listener) {
            mNegativeButtonListener = listener;
            return this;
        }

        public Builder setNegativeButton(CharSequence text, final OnClickListener listener) {
            mNegativeButtonListener = listener;
            return this;
        }

        public Builder setNeutralButton(int textId, final OnClickListener listener) {
            mNeutralButtonListener = listener;
            return this;
        }

        public Builder setNeutralButton(CharSequence text, final OnClickListener listener) {
            mNeutralButtonListener = listener;
            return this;
        }

        public Builder setOnCancelListener(OnCancelListener onCancelListener) {
            mOnCancelListener = onCancelListener;
            return this;
        }
        

        public Builder setOnDismissListener(OnDismissListener onDismissListener) {
            mOnDismissListener = onDismissListener;
            return this;
        }

        public Builder setOnKeyListener(OnKeyListener onKeyListener) {
            mOnKeyListener = onKeyListener;
            return this;
        }
        

        public Builder setItems(int itemsId, final OnClickListener listener) {
            mOnClickListener = listener;
            return this;
        }

        public Builder setItems(CharSequence[] items, final OnClickListener listener) {
            mOnClickListener = listener;
            return this;
        }

        public Builder setAdapter(final ListAdapter adapter, final OnClickListener listener) {
            mOnClickListener = listener;
            return this;
        }

        public Builder setCursor(final Cursor cursor, final OnClickListener listener,
                String labelColumn) {
            mOnClickListener = listener;
            return this;
        }

        public Builder setMultiChoiceItems(int itemsId, boolean[] checkedItems, 
                final OnMultiChoiceClickListener listener) {
            mOnCheckboxClickListener = listener;
            return this;
        }

        public Builder setMultiChoiceItems(CharSequence[] items, boolean[] checkedItems, 
                final OnMultiChoiceClickListener listener) {
            mOnCheckboxClickListener = listener;
            return this;
        }

        public Builder setMultiChoiceItems(Cursor cursor, String isCheckedColumn, String labelColumn, 
                final OnMultiChoiceClickListener listener) {
            mOnCheckboxClickListener = listener;
            return this;
        }

        public Builder setSingleChoiceItems(int itemsId, int checkedItem, 
                final OnClickListener listener) {
            mOnClickListener = listener;
            return this;
        }
        

        public Builder setSingleChoiceItems(Cursor cursor, int checkedItem, String labelColumn, 
                final OnClickListener listener) {
            mOnClickListener = listener;
            return this;
        }

        public Builder setSingleChoiceItems(CharSequence[] items, int checkedItem, final OnClickListener listener) {
            mOnClickListener = listener;
            return this;
        } 

        public Builder setSingleChoiceItems(ListAdapter adapter, int checkedItem, final OnClickListener listener) {
            mOnClickListener = listener;
            return this;
        }

        public Builder setOnItemSelectedListener(final AdapterView.OnItemSelectedListener listener) {
            mOnItemSelectedListener = listener;
            return this;
        }

        public Builder setView(View view) {
            return this;
        }

        public AlertDialog create() {
            return new AlertDialog();
        }

        public AlertDialog show() {
            AlertDialog dialog = create();
            return dialog;
        }
    }
    
}
