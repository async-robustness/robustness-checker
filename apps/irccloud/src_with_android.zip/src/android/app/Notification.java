package android.app;

/**
 * Created by burcuozkan on 12/06/16.
 */
public class Notification {
}
