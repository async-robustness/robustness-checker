package android.app;

/**
 * Created by burcuozkan on 12/06/16.
 */
public class NotificationManager {

    public void cancel(int id)
    {
    }

    public void cancel(String tag, int id)
    {
    }

    public void notify(int id, Notification notification)
    {
    }


    public void notify(String tag, int id, Notification notification)
    {

    }
}
