package android.app.backup;

import android.content.Context;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class BackupManager {

    public BackupManager(Context context) {

    }

    public void dataChanged() {

    }
}
