package android.app;

import android.widget.TabHost;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class TabActivity extends Activity {
    // eliminated view related tab methods addTab, etc..
    // tabs will be selected via external events

    private TabHost tabHost = new TabHost();

    public TabHost getTabHost() {
        return tabHost;
    }
}
