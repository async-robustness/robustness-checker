package android.app;

import android.content.Context;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class Application extends Context {

    public void onCreate() {

    }

    public void onTerminate() {

    }
}
