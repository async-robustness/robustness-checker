package android.preference;

/**
 * Created by burcuozkan on 12/06/16.
 */
public class CheckBoxPreference extends Preference {

    public void setChecked(boolean b) {

    }
}
