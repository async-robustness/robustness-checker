package android.preference;

import android.app.Activity;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class PreferenceActivity extends Activity {

    PreferenceManager mPreferenceManager = new PreferenceManager();

    public void addPreferencesFromResource(int preferencesResId) {
    }

    public PreferenceManager getPreferenceManager() {
        return mPreferenceManager;
    }

    public Preference findPreference(CharSequence key) {

        if (mPreferenceManager == null) {
            return null;
        }

        return new Preference();
    }
}
