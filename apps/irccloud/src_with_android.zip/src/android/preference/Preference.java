package android.preference;

/**
 * Created by burcuozkan on 12/06/16.
 */
public class Preference {

    private OnPreferenceChangeListener mOnChangeListener;
    private OnPreferenceClickListener mOnClickListener;

    public interface OnPreferenceChangeListener {
        boolean onPreferenceChange(Preference preference, Object newValue);
    }

    public interface OnPreferenceClickListener {
        boolean onPreferenceClick(Preference preference);
    }

    public void setOnPreferenceChangeListener(OnPreferenceChangeListener onPreferenceChangeListener) {
        mOnChangeListener = onPreferenceChangeListener;
    }

    public OnPreferenceChangeListener getOnPreferenceChangeListener() {
        return mOnChangeListener;
    }

    public void callOnPreferenceChangeListener(Preference p, Object o) {
        if(mOnChangeListener != null) {
            mOnChangeListener.onPreferenceChange(p, o);
        }
    }

    public void callOnPreferenceClickListener(Preference p) {
        if(mOnClickListener != null) {
            mOnClickListener.onPreferenceClick(p);
        }
    }

    public void setOnPreferenceClickListener(OnPreferenceClickListener onPreferenceClickListener) {
        mOnClickListener = onPreferenceClickListener;
    }

    public OnPreferenceClickListener getOnPreferenceClickListener() {
        return mOnClickListener;
    }

    public CharSequence getSummary() {
        return "";
    }

    public void setSummary(CharSequence summary) {

    }

    public void setEnabled(boolean enabled) {

    }

    public String getKey() {
        return "";
    }
}
