package android.preference;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by burcuozkan on 05/05/16.
 */
public class PreferenceManager {
    private static SharedPreferences pref;

    public static SharedPreferences getDefaultSharedPreferences(Context context) {
        if(pref == null) {
            pref = new SharedPreferences();
        }
        return pref;
    }

    public void setSharedPreferencesName(String name) {

    }
}
