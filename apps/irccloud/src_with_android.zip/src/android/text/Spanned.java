package android.text;

/**
 * Created by burcuozkan on 10/06/16.
 */
public class Spanned {

    public int length() {
        return 0;
    }
}
