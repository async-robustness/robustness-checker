package android.text;

/**
 * Created by burcuozkan on 02/06/16.
 */
public class Html {

    public static Spanned fromHtml(String source) {
        return new Spanned();
    }
}
