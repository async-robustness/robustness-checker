import android.content.Context;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;
import com.google.gson.JsonArray;
import com.irccloud.android.IRCCloudApplication;
import com.irccloud.android.activity.MessageActivity;
import com.irccloud.android.data.BuffersDataSource;
import com.irccloud.android.data.ServersDataSource;
import inst.SkipException;
import inst.ViolationChecker;

import java.util.ArrayList;

public class Tester {

    public static void main(String[] args) {


        MessageActivity ma = null;
        Context c = null;

        System.out.println("Started");
        try {
            ViolationChecker.initEvent();

            // Event 1 - Init Application
            //System.out.println("Initialize Irccloud app ");
            c = new Context();
            c.initApplication(IRCCloudApplication.class);

            // Load message activity
            //System.out.println("Initialize Message Activity ");
            ma = new MessageActivity();
            ma.onCreate(null);
            //ma.onStart(); not implemented in Message Activity
            ma.onResume();

            // cretae some server data
            // createServer(int cid, String name, String hostname, int port, String nick, String status, long lag, int ssl, String realname, String server_pass, String nickserv_pass, String join_commands, JsonObject fail_info, String away, JsonArray ignores, int order) {
            ma.server = ServersDataSource.getInstance().createServer(0, "", "", 0, "", "", 0, 0, "", "", "", "", null, "", new JsonArray(), 0);
            // create some buffer data
            //createBuffer(int bid, int cid, long min_eid, long last_seen_eid, String name, String type, int archived, int deferred, int timeout)
            ma.buffer = BuffersDataSource.getInstance().createBuffer(0, 0, 0, 0, "", "", 0, 0, 0);
            ViolationChecker.endEvent();
        } catch (SkipException e) {
            //System.out.println("Skipped in the outer level");
        }

        try {
            ViolationChecker.initEvent();

            // Event 2 - Write some text
            //System.out.println("Write \"Hello\" to the message text ");
            ma.messageTxt.setText("Hello");

            ViolationChecker.endEvent();

        } catch (SkipException e) {
            //System.out.println("Skipped in the outer level");
        }

        try {
            ViolationChecker.initEvent();

            // Event 3 - Click on "send" button
            //System.out.println("Click on the send button ");
            ma.messageTxt.callOnEditorActionListener(new TextView(), EditorInfo.IME_ACTION_SEND, new KeyEvent(EditorInfo.IME_ACTION_SEND));

            ViolationChecker.endEvent();

        } catch (SkipException e) {
            //System.out.println("Skipped in the outer level");
        }

        try {
            ViolationChecker.initEvent();

            // Event 4 - Double click on the user name
            //System.out.println("Double click on the user name ");
            ma.onUserDoubleClicked("Username");

            ViolationChecker.endEvent();

        } catch (SkipException e) {
            //System.out.println("Skipped in the outer level");
        }


        //System.out.println("Done!");
    }
}
